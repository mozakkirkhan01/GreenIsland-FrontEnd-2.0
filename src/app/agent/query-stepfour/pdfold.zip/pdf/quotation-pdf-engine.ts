import { PDF_STYLES, PDF_DEFAULT_STYLE } from './theme/styles';
import { PAGE_MARGINS } from './theme/spacing';
import { COLORS } from './theme/colors';
import { ThemeConfig, mergeThemeConfig } from './theme/theme.config';

import { buildHeader } from './components/header.component';
import { buildFooter } from './components/footer.component';

import { buildCoverSection } from './sections/cover/cover.section';
import { buildSummarySection } from './sections/summary/summary.section';
import { buildPackageSummarySection } from './sections/package-summary/package-summary.section';
import { buildAccommodationSection } from './sections/accommodation/accommodation.section';
import { buildTransportSection } from './sections/transport/transport.section';
import { buildActivitySection } from './sections/activities/activity.section';
import { buildItinerarySection } from './sections/itinerary/itinerary.section';
import { buildInclusionSection } from './sections/inclusion/inclusion.section';
import { buildTermsSection } from './sections/terms/terms.section';
import { buildBackCoverSection } from './sections/back-cover/back-cover.section';

export interface PdfBuildContext {
  tripInfo: any;
  quoteHeader: any;
  // Optional pricing object passed from the caller (keeps GST settings, totals, etc.)
  pricing?: any;
  packageTypes: any[];
  hotelsByPackage: (pkgId: number) => any[];
  similarHotels: any[];
  specialInclusions: any[];
  hasSimilarHotels: (quoteHotelId: number) => boolean;
  daySlots: any[];
  servicesForDay: (dayNumber: number) => any[];
  activityGroupsForDay: (dayNumber: number) => any[];
  activityGroupTitle: (group: any) => string;
  serviceTitle: (svc: any) => string;
  serviceSubtitle: (svc: any) => string;
  serviceBreakdown: (svc: any) => string;
  daySchedule: (dayNumber: number) => { title: string; intro: string; sections: { heading: string; body: string }[] } | null;
  rawDaySchedule: (dayNumber: number) => string;
  inclusions: any[];
  exclusions: any[];
  inclusionText: (i: any) => string;
  exclusionText: (e: any) => string;
  terms: any[];
  hasTerms: boolean;
  termHtml: (t: any) => string;
  packageQuotePrice: (pkgId: number) => number;
  packageGrandTotal: (pkgId: number) => number;
  packageCostPrice: (pkgId: number) => number;
  guestCategoryTotals: (pkgId: number) => { label: string; count: number; paxLabel: string; amount: number }[];
  isOverallPricing: (pkgId: number) => boolean;
  pricingSnapshots: any[];
  packageSummaries: any[];
  // Optional helper: returns true when GST is included for a given package id
  isGstIncluded?: (pkgId: number) => boolean;
  durationLabel: string;
  totalGuestCount: number;
  formatCurrency: (n: number) => string;
  formatQuotationNo: (n: any) => string;
  ordinal: (n: number) => string;
  formatDateShort: (v: any) => string;
  formatDateLong: (v: any) => string;
  removeTransportActivities: boolean;
  removeItinerary: boolean;
  removeTerms: boolean;
  hideTotalPrice: boolean;
  coverImage: string | null;
  logoImage: string | null;
  sanitizeHtml: (html: string) => string;
  agencyPhone?: string;
  agencyEmail?: string;
  agencyWebsite?: string;
  /**
   * Optional partial theme override (agency name/branding/watermark), merged
   * on top of the THEME_CONFIG defaults for this render only — lets callers
   * white-label the PDF for a different agency without touching this file.
   */
  themeOverride?: Partial<ThemeConfig> | null;
}

const SECTION_BUILDERS: Array<(ctx: PdfBuildContext) => any[]> = [
  buildCoverSection,
  buildSummarySection,
  buildPackageSummarySection,
  buildAccommodationSection,
  buildTransportSection,
  buildActivitySection,
  buildItinerarySection,
  buildInclusionSection,
  buildTermsSection,
  buildBackCoverSection,
];

export class QuotationPdfEngine {
  build(ctx: PdfBuildContext): any {
    const content = SECTION_BUILDERS.flatMap(build => build(ctx));
    const theme = mergeThemeConfig(ctx.themeOverride);

    return {
      pageSize: 'A4',
      pageMargins: PAGE_MARGINS,
      background: (currentPage: number, pageSize: any) =>
        currentPage === 1 ? null : buildWatermark(ctx, theme, pageSize),
      header: (currentPage: number) => buildHeader({
        agencyName: ctx.tripInfo?.AgencyName || theme.agency.name,
        logoImage: ctx.logoImage,
        quotationLabel: `Trip# ${ctx.formatQuotationNo(ctx.tripInfo?.QuotationNo)}`,
        destinationName: ctx.tripInfo?.DestinationName,
        website: ctx.agencyWebsite || theme.agency.website,
        theme,
      }, currentPage),
      footer: (currentPage: number, pageCount: number) => buildFooter({
        agencyName: ctx.tripInfo?.AgencyName || theme.agency.name,
        phone: ctx.agencyPhone || theme.agency.phone,
        email: ctx.agencyEmail || theme.agency.email,
        website: ctx.agencyWebsite || theme.agency.website,
        address: theme.agency.headOffice,
        theme,
      }, currentPage, pageCount),
      content,
      styles: PDF_STYLES,
      defaultStyle: PDF_DEFAULT_STYLE,
    };
  }
}

function buildWatermark(ctx: PdfBuildContext, theme: ThemeConfig, pageSize: { width: number; height: number }): any {
  if (!theme.watermark.enabled) return null;
  const label = theme.agency.shortName || theme.agency.name;
  if (!label) return null;

  // One large, very faint diagonal mark centered on the page, instead of a
  // repeating small-text grid that competed with the page content.
  return {
    text: label,
    fontSize: theme.watermark.fontSize,
    color: COLORS.watermark,
    opacity: theme.watermark.opacity,
    angle: theme.watermark.angle,
    alignment: 'center',
    absolutePosition: { x: 0, y: pageSize.height / 2 - 30 },
    // Full page width so the centered text alignment centers on the page.
    width: pageSize.width,
  };
}

export { QuotationPdfEngine as QuotationPdfBuilder };
