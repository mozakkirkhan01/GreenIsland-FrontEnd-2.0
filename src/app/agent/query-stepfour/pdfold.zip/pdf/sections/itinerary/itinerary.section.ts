import type { PdfBuildContext } from '../../quotation-pdf-engine';
import { buildSectionTitle } from '../../components/section-title.component';
import { buildItineraryCard } from '../../components/itinerary-card.component';
import { htmlToPdfMake } from '../../helpers/html-to-pdfmake';

/**
 * Day-wise itinerary, sourced from the rich-text (Quill) editor content the
 * user types in on the quote-builder step, one block per day.
 *
 * Previously this ran `ctx.daySchedule()` — a hand-rolled parser that split
 * the schedule text on blank lines and lines starting with "•" — through
 * `toContent()`, which only treated the string as HTML if it *also* matched
 * an HTML-tag regex. Quill always emits real HTML (`<p>…</p>`, `<ul><li>…`,
 * etc.), never blank-line/bullet-prefixed plain text, so that parser split
 * each day's schedule into one giant unparsed blob containing literal
 * `<p>`/`<strong>` tags instead of rendering it. The regex fallback rarely
 * even triggered because a full Quill document reliably contains a `<`,
 * so in practice this produced walls of raw tag soup in the PDF.
 *
 * Fix: render the actual Quill HTML directly — sanitize it via
 * `ctx.sanitizeHtml` (Angular's DomSanitizer, wired in from
 * query-stepfour.ts) and convert it with the existing `htmlToPdfMake`
 * helper, the same helper already used for Terms & Conditions.
 */
export function buildItinerarySection(ctx: PdfBuildContext): any[] {
  if (ctx.removeItinerary) return [];

  const days = ctx.daySlots.filter((d: any) => {
    const raw = ctx.rawDaySchedule(d.dayNumber);
    return !!raw && raw.trim().length > 0;
  });
  if (!days.length) return [];

  const out: any[] = [buildSectionTitle('Day-Wise Itinerary', 'What to expect, day by day')];

  for (const day of days) {
    const sched = ctx.daySchedule(day.dayNumber);
    const rawHtml = ctx.rawDaySchedule(day.dayNumber) || '';
    const sanitized = ctx.sanitizeHtml(rawHtml);

    out.push(buildItineraryCard({
      dayNumber: day.dayNumber,
      ordinalSuffix: ctx.ordinal(day.dayNumber),
      dateLabel: ctx.formatDateLong(day.date),
      title: sched?.title || '',
      introContent: htmlToPdfMake(sanitized),
      sections: [],
    }));
  }
  return out;
}
